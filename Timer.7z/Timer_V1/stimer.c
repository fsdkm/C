#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>

#include "sfuns.h"
#include "stimer.h"

//Т.к. доступ до функции обработчика событий возможен из нескольких потоков,
//то для синхронизации понадобился мютекс 
static pthread_mutex_t mutex;

//Для одноразовой инициализации мьютекса и реализации патерна "одиночка"
//просто ввел локальную глобальную переменную 
static t_bool single_init = false;

//Подсчёт количества экземпляров таймера необходим для того, 
//что бы в деструкторе понимать, что у нас ещё кто-то остался или нет.
static int n_timers = 0;

//Структура класса с приватными полями
struct stimer {
    int interval;      //Периодичность работы
    t_bool enable;     //Состояние активности 
    pthread_t tid;     //Идентификатор потока
    t_stimer_events* listener; //Слушатель событий
    void* parent;              //Чьих рода будет
};

//Фукция отдельного потока
void* execute_thread(void* arg)
{
    //Передача указателя на экзем созданного объекта таймера
    t_stimer* timer = (t_stimer*) arg;
    
    //Включает возможность немедленного завершения потока
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

    do {
        //Отправляет поток в сон на заданный интервал (в секундах)
        sleep(timer->interval); 
        
        //Так как для обработки событий, для всех потоков, используется 
        //одна и таже функция, то доступ к ней синхронизируем мютексом
        pthread_mutex_lock(&mutex);
        timer->listener->on_time(timer);
        pthread_mutex_unlock(&mutex);

    //Так как поток может завершаться немедленно,
    //то каких-то условий для выхода из цикла не требуется         
    } while(1);  
}

//Функция конструктор
t_stimer* stimer_create(void* parent, int* exception)
{
    int status;

    //Выделяем память под новый объект
    t_stimer* new_stimer = malloc(sizeof(t_stimer));
    //Проверяем, что всё замечательно или возвращаемся с кодом ошибки
    if(new_stimer == NULL){
        *exception = errno;
        return NULL;
    } 

    //Инициализируем переменные структуры-таймера
    new_stimer->enable = false;
    new_stimer->interval = 1;
    new_stimer->parent = parent;
    
    n_timers++;
    
    //Однократная инициализация общего мютекса
    if(single_init == false) {
       status = pthread_mutex_init(&mutex,NULL);
       if(0!=status){
           free(new_stimer);
           *exception = status;
           return NULL;
       }
       single_init = true;     
    }
    
    return new_stimer;
}

//Функция деструктор
void stimer_destroy(t_stimer* timer)
{
    if(n_timers > 0){
        if(timer->enable == true){
            pthread_cancel(timer->tid);
            timer->enable = false;
        }
        free(timer);
        timer = NULL;
        n_timers--;
        if(n_timers == 0){
            pthread_mutex_destroy(&mutex);
            single_init = false;
        }
    }
}

//Включение и выключение таймера
void stimer_set_active(t_stimer* timer, t_bool enable)
{ 
    int status;

    if((timer->enable == false) && (enable == true)){
        status = pthread_create(&timer->tid,0,execute_thread,timer);
        if(0!=status){
            timer->listener->on_error(timer,&status);
        }
    }
    if((timer->enable == true) && (enable == false)){
        status = pthread_cancel(timer->tid);
        if(0!=status){
            timer->listener->on_error(timer,&status);
        }
    }
    timer->enable = enable;
}
//Во время включения и выключения таймера создаётся и соответственно
//уничтожает дополнительный поток. На это тратятся ресурсы, что не соответствует
//предъявляемым к таймеру требованиям. Такая реализация имеет место быть
//только при условии не частой или единовременной активации таймера.

//Далее функции "сеттеры" и "геттеры" для доступа к переменным структуры 
void stimer_set_interval(t_stimer* timer, int value)
{
    timer->interval =value;
}

t_bool stimer_get_active(t_stimer* timer)
{
    return timer->enable;
}

void stimer_set_listener(t_stimer* timer, t_stimer_events* listener)
{
    timer->listener = listener;
}

void stimer_set_parent(t_stimer* timer, void* parent)
{
    timer->parent = parent;
}

void* stimer_get_parent(t_stimer* timer)
{
    return timer->parent;
}