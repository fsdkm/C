#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>

#include "sfuns.h"
#include "stimer.h"

static t_bool single_init = false;
static pthread_t tid = 0;
static t_bool terminate = false;

static int n_timers = 0;

struct stimer {
    int interval;

    struct timespec time_before;
    struct timespec time_after;

    t_bool enable;
    t_stimer_events* listener;
    void* parent;
};

static t_stimer** timers;

void* execute_thread(void* arg)
{
    int i;
    int interval;

    //Период контроля времени задаётся с точностью в 10мс.
    //Контролировать в данной реализации таймера точность в 1мс не имеет смысла,
    //так как это почти не возможно и, как правило, не требуется,
    //а крутить проверку таймеров с такой частотой только "пожерать" ресурсы процессора.

    struct timespec sleep_period = {0,9999999}; //Период, почти 10 мс

    do {
        for(i=0;i<n_timers;i++){
            if(timers[i]->enable == false){
                //Если таймер не активный, то присваиваем ему начальное значение
                clock_gettime(CLOCK_REALTIME, &timers[i]->time_before);
            }
        }
        //Засыпаем на 10мс
        nanosleep(&sleep_period , NULL);

        for(i=0;i<n_timers;i++){
            if(timers[i]->enable == true){
                //Получаем текущее значение времени.
                clock_gettime(CLOCK_REALTIME, &timers[i]->time_after);
                //Вычисляем прошедшее время ожидания
                interval = ((timers[i]->time_after.tv_sec-timers[i]->time_before.tv_sec)*1000000000 
                            +timers[i]->time_after.tv_nsec-timers[i]->time_before.tv_nsec)/1000000; 
                //Проверяем условие, если ОК, то обновляем время и формируем событие
                if(interval >= timers[i]->interval){
                    clock_gettime(CLOCK_REALTIME, &timers[i]->time_before);
                    timers[i]->listener->on_time(timers[i]);
                }
            }
        }
     } while (terminate == false);
}

t_stimer* stimer_create(void* parent, int* exception)
{
    int status;

    t_stimer* new_stimer = malloc(sizeof(t_stimer));
    if(new_stimer == NULL){
        *exception = errno;
        return NULL;
    }
    new_stimer->parent = parent;
    new_stimer->interval = 1000;
    new_stimer->enable = false;
    new_stimer->listener = NULL;
    clock_gettime(CLOCK_REALTIME,&new_stimer->time_before);

    n_timers++;
    timers = (t_stimer**)realloc(timers, n_timers*sizeof(t_stimer*));

    timers[n_timers-1] = new_stimer;

    if(single_init == false){
       terminate = false; 
       status = pthread_create(&tid,0,execute_thread,NULL);
       if(0!=status){
           *exception = status;
           n_timers=0;
           free(timers);
           free(new_stimer);
           new_stimer = NULL;
           return NULL;
       }
       single_init = true;
    }
    return new_stimer;
}

void stimer_destroy(t_stimer* timer)
{
    int i;
    int j;

    if(n_timers > 0){
        for(i=0;i<n_timers;i++){
            if(timer == timers[i]){
                for(j=i;j<(n_timers-1);j++){
                    timers[j]=timers[j+1];
                }
                timers = (t_stimer**)realloc(timers, (n_timers-1)*sizeof(t_stimer*));
                n_timers--;
                break;
            }
        }
        if(n_timers == 0){
            terminate = true;
            pthread_join(tid,NULL);
            single_init = false;
            timers = NULL;
        }
    }
    free(timer);
    timer = NULL;
}

void stimer_set_interval(t_stimer* timer, int value)
{
    timer->interval = value;
}

void stimer_set_active(t_stimer* timer, t_bool enable)
{
    timer->enable = enable;
}

t_bool stimer_get_active(t_stimer* timer)
{
    return timer->enable;
}

void stimer_set_listener(t_stimer* timer, t_stimer_events* listener)
{
    timer->listener = listener;
}

void stimer_set_parent(t_stimer* timer, void* parent)
{
    timer->parent = parent;
}
void* stimer_get_parent(t_stimer* timer)
{
    return timer->parent;
}