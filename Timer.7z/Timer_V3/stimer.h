/**
 * 1. Интервал таймера задаётся в секундах;
 * 2. Минимальный интервал таймера 1 секунда;
 * 3. Все экземпляры таймера задейтсвуют единый поток.
*/

#ifndef _STIMER_H_
#define _STIMER_H_

#include <stdlib.h> 
#include "sfuns.h" //В sfuns.h просто определён тип t_bool

//Структура определяющая новый класс 
struct stimer;
typedef struct stimer t_stimer;

//Структура событий.
typedef struct stimer_events {
    void (*on_time)(t_stimer* timer);
    void (*on_error)(t_stimer* timer, int* exception);
} t_stimer_events;

//Конструктор/деструктор
t_stimer* stimer_create(void* parent, int* exception);
void stimer_destroy(t_stimer* timer);

//Интервал
void stimer_set_interval(t_stimer* timer, int value);

//Активация/деактивация таймера
void stimer_set_active(t_stimer* timer, t_bool enable);
t_bool stimer_get_active(t_stimer* timer);

//Слушатель события 
void stimer_set_listener(t_stimer* timer, t_stimer_events* listener);

//Фамилия родителя
void stimer_set_parent(t_stimer* timer, void* parent);
void* stimer_get_parent(t_stimer* timer);

#endif