#include <unistd.h>
#include <termios.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/select.h>

#include "sfuns.h"

int sgetch()
{
    int ch;
    struct termios oldt, newt;

    tcgetattr( STDIN_FILENO, &oldt );

    newt = oldt;
    newt.c_lflag &= ~( ICANON | ECHO );

    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );

    return ch;
}

int kbhit()
{
    struct timeval tv = { 0L, 0L };
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(0, &fds);
    return select(1, &fds, NULL, NULL, &tv);
}

char* assign_string(const char* literal)
{
    int i,len = 0;
    char* buff;

    while (literal[len])len++;
    buff = malloc(len*sizeof(char));
    for(i=0;i<len;i++)buff[i]=literal[i];

    return buff;
}

void synch(void (*function),pthread_mutex_t *mutex)
{
    pthread_mutex_lock(mutex);
        &function;
    pthread_mutex_unlock(mutex);
}