#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <termios.h>

#include "sfuns.h"
#include "stimer.h"

//Объявлена пара экземпляров таймера
t_stimer* timer1; 
t_stimer* timer2;
//Слушатель событий от таймера
t_stimer_events listener;

//Функции обработки событий
void ontime_events(t_stimer* timer)
{
    time_t curent_time;
    time(&curent_time);

    if(timer == timer1){
        printf("Event timer 1 %s",ctime(&curent_time));
    }
    if(timer == timer2){
        printf("Event timer 2 %s",ctime(&curent_time));
    }
}

void onerror_events(t_stimer* timer, int* exception)
{
    if(timer == timer1){
        printf("Error timer 1 %d\n", *exception);
    }
    if(timer == timer2){
        printf("Error timer 2 %d\n", *exception);
    }
}

int main(int args, char** argv)
{
    unsigned char key;
    int err;

    //Присвоение слушателю событий его функций обработчиков
    listener.on_time = ontime_events;
    listener.on_error = onerror_events;

    //Инициализация объектов таймера. Т.к. родитель нам в
    //данном случае не нужен, то первым параметром пишем NULL 
    timer1 = stimer_create(NULL,&err);
    if(timer1 == NULL){
        printf("Ceate timer1. Error number: %d\n",err);
        return 0;
    }
    timer2 = stimer_create(NULL,&err);
    if(timer2 == NULL){
        printf("Ceate timer2. Error number: %d\n",err);
        stimer_destroy(timer1);
        return 0;
    }

    //Регистрация слушателя
    stimer_set_listener(timer1,&listener);
    stimer_set_listener(timer2,&listener);

    //Установка периодичности работы таймеров
    //Если использвать функцию sleep, то интервал будет задаваться в секундах.
    //Для функции nanosleep, в примерах, интервал будет задаваться в миллисекундах.
    stimer_set_interval(timer1, 3000);
    stimer_set_interval(timer2, 5000);

    stimer_set_active(timer1, true);
    stimer_set_active(timer2, true);

    //Обработка клавиатуры
    do {
        key = sgetch();
        printf("key: %d\n",key);
        if(key==49){ //1
            stimer_set_active(timer1, false);
            printf("timer1 active false\n");
        }
        if(key==50){ //2
            stimer_set_active(timer1, true);
            printf("timer1 active true\n");
        }
        if(key==51){ //3
            stimer_set_active(timer2, false);
            printf("timer2 active false\n");
        }
        if(key==52){ //4
            stimer_set_active(timer2, true);
            printf("timer2 active true\n");
        }
    } while (key!=27); //ESC

    stimer_destroy(timer1);
    stimer_destroy(timer2);

    return 0;
}