#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>

#include "sfuns.h"
#include "stimer.h"

//Мьютекс необходим для синхронизации доступа к общим ресурсам
static pthread_mutex_t mutex;

//Переменная необходима для однократной инициализации переменных в конструкторе
static t_bool single_init = false;

static int n_timers = 0;

struct stimer {
    //Свойства таймера
    struct timespec sleep_period;
    t_bool enable;

    //Переменные для работы с потоком
    pthread_t tid;
    t_bool terminate;

    //Те, с кем взаимодействует объект таймера
    t_stimer_events* listener;
    void* parent;

    /* Бездействие таймера в режиме "выключен"
    будет блокироваться через переменную условия */
    pthread_cond_t cond_active;
    pthread_mutex_t cond_lock;
};

void* execute_thread(void* arg)
{
    int status;

    t_stimer* timer = (t_stimer*) arg;

    do {
        //Блокировка потока через переменную условия
        pthread_mutex_lock(&timer->cond_lock);
            if(timer->enable == false){
                /* Если таймер выключен, то засыпаем и ждём "будильник",
                сигнал условия деблокировки. */
                pthread_cond_wait(&timer->cond_active,&timer->cond_lock);
            }
        pthread_mutex_unlock(&timer->cond_lock);

        /* Если nanosleep нормально доспала, то можно сформировать событие,
        а для этого необходимо контролировать статус */
        status = nanosleep(&timer->sleep_period, NULL);

        if(timer->enable == true && status == 0){
            pthread_mutex_lock(&mutex);
                timer->listener->on_time(timer);
            pthread_mutex_unlock(&mutex);
        }
    } while(timer->terminate == false);
}

void signal_handler(int sig)
{
    /*  Пустой обработчик сигнала.
    Фактически данная функция здесь нужна толь для
    того что бы переопределить реакцию потока на сигнал SIGUSR1.
    По умолчанию реакция на сигнал это "завершение работы".
    Сигнал необходим чтобы прервать сон nanosleep.*/
}

t_stimer* stimer_create(void* parent, int* exception)
{
    int status;

    t_stimer* new_stimer = malloc(sizeof(t_stimer));
    if(new_stimer == NULL){
        *exception = errno;
        return NULL;
    }

    new_stimer->enable = false;
    new_stimer->terminate = false;
    new_stimer->sleep_period.tv_sec=1;
    new_stimer->sleep_period.tv_nsec=0L;
    new_stimer->parent = parent;

    if(single_init == false) {
       //Переопределяем обработчик
       signal(SIGUSR1,signal_handler);

       //Инициализируем общий мьютекс
       status = pthread_mutex_init(&mutex,NULL);
       if(0!=status) goto crash_object;
       single_init = true;
    }
    status = pthread_mutex_init(&new_stimer->cond_lock,NULL);
    if(0!=status) goto crash_object;

    status = pthread_create(&new_stimer->tid,0,execute_thread,new_stimer);
    if(0!=status){
        pthread_mutex_destroy(&new_stimer->cond_lock);
        goto crash_object;
    }
    n_timers++;
    return new_stimer;

    crash_object: //Здесь сворачиваемся если что-то пошло не так.
    if((0 == n_timers) && (single_init == true)){
        pthread_mutex_destroy(&mutex);
        single_init = false;
    }
    free(new_stimer);
    *exception = status;
    return NULL;
}

void stimer_set_active(t_stimer* timer, t_bool enable)
{ 
    timer->enable = enable;
    //Будим таймер, если он спит
    pthread_mutex_lock(&timer->cond_lock);
    pthread_cond_signal(&timer->cond_active);
    pthread_mutex_unlock(&timer->cond_lock);

    //Прерываем и сбрасываем nanosleep
    pthread_kill(timer->tid,SIGUSR1);
}

void stimer_destroy(t_stimer* timer)
{
    if(n_timers > 0){
        //Останавливаем таймер
        timer->terminate = true;
        stimer_set_active(timer,false);
        //Ждем завершения потока
        pthread_join(timer->tid,NULL);
        //Далее всё чистим
        pthread_mutex_destroy(&timer->cond_lock);

        free(timer);
        timer = NULL;
        n_timers--;
        if(n_timers == 0){
            pthread_mutex_destroy(&mutex);
            single_init = false;
        }
    }
}
 
void stimer_set_interval(t_stimer* timer, int value)
{
    ldiv_t t = ldiv(value, 1000);
    timer->sleep_period.tv_sec = t.quot;
    timer->sleep_period.tv_nsec = t.rem * 1000000;
}

t_bool stimer_get_active(t_stimer* timer)
{
    return timer->enable;
}

void stimer_set_listener(t_stimer* timer, t_stimer_events* listener)
{
    timer->listener = listener;
}

void stimer_set_parent(t_stimer* timer, void* parent)
{
    timer->parent = parent;
}

void* stimer_get_parent(t_stimer* timer)
{
    return timer->parent;
}