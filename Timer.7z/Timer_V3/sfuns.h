#include <stdlib.h>

#ifndef _SFUNS_H_
#define _SFUNS_H_

#ifndef false
#define false 0
#endif

#ifndef true
#define true  1
#endif

#ifndef t_bool
typedef unsigned char t_bool;
#endif

#define REMOVE_ARRAY_ITEM(index, array, len, type) do{\
    int __i;\
    if((len) > 1){\
        for(__i=index;__i<((len)-1);__i++)array[__i] = array[__i+1];\
        array = realloc(array, ((len)-1)*sizeof(type));\
    }\
} while(0)

int sgetch(void);

int kbhit();

char* assign_string(const char* literal);

void synch(void (*function),pthread_mutex_t *mutex);

#endif