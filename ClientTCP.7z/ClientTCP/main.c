#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "sclienttcp.h"
#include "sfuns.h"

t_sclienttcp_remote_server server;
t_sclienttcp* client_1;
t_sclienttcp* client_2;
t_sclienttcp_events events_listener;

t_bool m_terminate = false;
t_bool connect_client1 = false;
t_bool connect_client2 = false;
int exception;

unsigned char bytes[] = {0x31,0x32,0x33};

void on_connect(t_sclienttcp* client)
{
    if(client == client_1){
        printf("Connected client_1 \n");
        connect_client1 = true;
    }
    if(client == client_2){
        printf("Connected client_2\n");
        connect_client2 = true;
    }

    sclienttcp_data_push(client, bytes, 3);
}

void on_disconnect(t_sclienttcp* client)
{
    if(client == client_1){
        printf("Disconnected client_1 \n");
        connect_client1 = false;
    }
    if(client == client_2){
        printf("Disconnected client_2\n");
        connect_client2 = false;
    }
}

void on_data_received(t_sclienttcp* client, void* n_bytes)
{
    int num;
    unsigned char* buff;

    num = *(int*)n_bytes;
    buff = sclienttcp_data_pull(client);
    write(1,buff,num);
}

void on_error(t_sclienttcp* client, void* error)
{
    if(client == client_1){
        printf("Error client_1 %d\n",(int*)error);
    }
    if(client == client_2){
        printf("Error client_2 %d\n",(int*)error);
    }
    m_terminate = true;
}

int str2int(char *s)
{
    int temp=0;
    int i=0;
    int sign=0;

    if(s[i]=='-'){
       sign = 1;
       i++;
    }
    while(s[i]>=0x30 && s[i]<=0x39){
       temp = temp+(s[i]&0x0f);
       temp = temp*10;
       i++;
    }
    temp = temp / 10;
    if(sign == 1) temp = -temp;
    return temp;
}

int main(int argc, char **argv)
{   
    int key=0;
    int i,len;
    int status;
    unsigned char str[64];

    int sock_port;
    
    if(argc!=3){
      printf("Неверное количество параметров!\n");
      printf("Введите правильно номер порта\n");

      return 1;
    }

    sock_port = str2int(argv[2]);
    if((sock_port<0)||(sock_port>65536)){
      printf("Необоходимо правильно указать порт\n");
      return 2;
    }

    events_listener.on_connect = on_connect; 
    events_listener.on_disconnect = on_disconnect;
    events_listener.on_data_received = on_data_received;
    events_listener.on_error = on_error;
 
    server.address = argv[1];
    server.port = sock_port;
    server.recv_buff_size = 2048;

    client_1 = sclienttcp_create(&exception);
    if(client_1 == NULL){
        printf("Client 1 Exception: %d",exception);    
        return -1;
    }
    sclienttcp_set_server(client_1,&server);
    sclienttcp_set_listener(client_1,&events_listener);

    client_2 = sclienttcp_create(&exception);
    if(client_2 == NULL){
        printf("Client 2 Exception: %d",exception);
        return -1;
    }
    sclienttcp_set_server(client_2,&server);
    sclienttcp_set_listener(client_2,&events_listener);

    status = sclienttcp_socket_connect(client_1);
    if(status!=0) return status;

    status = sclienttcp_socket_connect(client_2);
    if(status!=0) return status;

    while (m_terminate == false) {
        memset(str,0,sizeof(str));
        scanf("%s",str);
        len=0; while(str[len])len++; 

        if(strcmp(str,"exit")==0){
            sclienttcp_socket_disconnect(client_1);
            sclienttcp_socket_disconnect(client_2);
            m_terminate = true;    
        }else{
            sclienttcp_data_push(client_1, str, len);
            sclienttcp_data_push(client_2, str, len);
        }
    }     
    
    while (connect_client1 || connect_client2) sleep(1);
 
    sclienttcp_destroy(client_1);
    sclienttcp_destroy(client_2);

    return 0;
}