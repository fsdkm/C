#include <stdlib.h>

#ifndef _SFUNS_H_
#define _SFUNS_H_

#ifndef false
#define false 0
#endif

#ifndef true
#define true  1
#endif

#ifndef t_bool
typedef unsigned char t_bool;
#endif



#define REMOVE_ARRAY_ITEM(index, array, size, type) do{\
    int __i;\
    int __j=0;\
    type* __temp;\
    if((size) > 1){\
        __temp = (type*)calloc((size-1),sizeof(type));\
        for(__i=0;__i<(size);__i++){\
            if(__i!=(index)){\
                __temp[__j] = array[__i];\
                __j++;\
            }\
        }\
        array = realloc(array, ((size)-1)*sizeof(type));\
        for(__i=0;__i<((size)-1);__i++){array[__i]=__temp[__i];}\
        free(__temp);\
        __temp = NULL;\
    }\
} while(0)

int sgetch(void);

int kbhit();

char* assign_string(const char* literal);

#endif