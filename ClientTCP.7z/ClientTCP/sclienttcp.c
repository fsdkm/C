#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#include "sclienttcp.h"
#include "sfuns.h"

pthread_mutex_t mutex;
static t_bool mutex_was_init = false;

static int n_clients = 0;

typedef enum client_events{
   ON_CONNECT,
   ON_DISCONNECT,
   ON_DATA_RECEIVED,
   ON_ERROR
} t_client_events;

struct sclienttcp {
    t_bool active_status;
    t_bool terminate;

    t_sclienttcp_remote_server* remote_srv;

    unsigned char* recv_buff;
    int recv_bytes;

    int fd_socket; 
    struct sockaddr_in* address_in;

    t_bool connect_resolution;

    t_sclienttcp_events* listener;

    pthread_t tid;
    pthread_attr_t attr;

    pthread_mutex_t* mutex;
    void (*call_listener)(t_sclienttcp*, t_client_events, void*);
    int (*sclienttcp_socket_disconnect)(t_sclienttcp*);
};

static t_sclienttcp** clients;

void call_listener(t_sclienttcp* client, t_client_events event, void* data)
{
    switch (event)
    {
    case ON_CONNECT:
        client->listener->on_connect(client);
        break;
    case ON_DISCONNECT:
        client->listener->on_disconnect(client); 
        break;
    case ON_DATA_RECEIVED:
        client->listener->on_data_received(client,data);
        break;
    case ON_ERROR:
        client->listener->on_error(client,data);
        break;
    }   
}

void* execute_thread(void* arg)
{
    int status;
    t_sclienttcp* client = (t_sclienttcp*)arg;

    status = connect(client->fd_socket, (struct sockaddr*)client->address_in, sizeof(struct sockaddr_in));
    if(status < 0){
        pthread_mutex_lock(client->mutex);
            client->call_listener(client,ON_ERROR,(void*)ERR_CONNECT);
        pthread_mutex_unlock(client->mutex);
        client->connect_resolution = true; 
    } else {
        pthread_mutex_lock(client->mutex);
            client->call_listener(client,ON_CONNECT,NULL);
        pthread_mutex_unlock(client->mutex);
        client->active_status = true;
        while(client->terminate == false){
            memset(client->recv_buff,0,client->remote_srv->recv_buff_size*sizeof(unsigned char));              
            client->recv_bytes = recv(  client->fd_socket, 
                                        client->recv_buff,
                                        client->remote_srv->recv_buff_size,0);
            pthread_mutex_lock(client->mutex);
                if(client->recv_bytes > 0){
                    client->call_listener(client,ON_DATA_RECEIVED,(void*) &client->recv_bytes);
                } 
                if(client->recv_bytes == 0){
                    client->sclienttcp_socket_disconnect(client); 
                }
                if(client->recv_bytes < 0){
                    client->call_listener(client,ON_ERROR,(void*)ERR_READ_DATA);
                }
            pthread_mutex_unlock(client->mutex);
        } 
        client->terminate == false;
    }
}

t_sclienttcp* sclienttcp_create(int* exception)
{
    int status;
    t_sclienttcp* new_client;
   
    new_client = (t_sclienttcp*)malloc(sizeof(t_sclienttcp));
    new_client->fd_socket = socket(AF_INET, SOCK_STREAM, 0);

    if(-1 == new_client->fd_socket){
        *exception = ERR_CREATE_SOCKET;
        free(new_client);
        return NULL;   
    }

    if(mutex_was_init == false){
        status = pthread_mutex_init(&mutex,NULL);
        if(status != 0){
            *exception = ERR_CREATE_MUTEX;
            free(new_client);
            return NULL;            
        } else {
            mutex_was_init = true;   
        } 
    } 

    new_client->remote_srv = (t_sclienttcp_remote_server*)malloc(sizeof(t_sclienttcp_remote_server));
    new_client->address_in = malloc(sizeof(struct sockaddr_in));
    new_client->recv_buff = malloc(1024*sizeof(unsigned char));    
    new_client->connect_resolution = true; 
    new_client->active_status = false;
    new_client->terminate = false;
    new_client->remote_srv->recv_buff_size = 1024;
    new_client->mutex = &mutex;
    new_client->call_listener = call_listener;
    new_client->sclienttcp_socket_disconnect = sclienttcp_socket_disconnect;

    n_clients++; 
    clients = (t_sclienttcp**)realloc(clients, n_clients*sizeof(t_sclienttcp*));

    clients[n_clients-1] = new_client;

    return new_client;
}

void sclienttcp_destroy(t_sclienttcp* client)
{
    int status;
    int i;
    int j;

    if(n_clients > 0){
        pthread_cancel(client->tid);
        pthread_join(client->tid,NULL);

        for(i=0;i<n_clients;i++){
            if(client == clients[i]){
                free(client->address_in);
                free(client->remote_srv);
                free(client->recv_buff);
                for(j=i;j<(n_clients-1);j++){
                    clients[j]=clients[j+1];
                }
                clients = (t_sclienttcp**)realloc(clients, n_clients*sizeof(t_sclienttcp*));
                n_clients--;
                break;
            }
        }    
        
        if(n_clients == 0){
            clients = NULL;
            if(mutex_was_init == true){  
                status = pthread_mutex_destroy(&mutex);
                if(status !=0){
                    call_listener(client,ON_ERROR,(void*)ERR_DESTROY_MUTEX);
                } else {
                    mutex_was_init = false;    
                }
            }
        }
        free(client);
        client = NULL;
    }
}

void sclienttcp_set_listener(t_sclienttcp* client, t_sclienttcp_events* listener)
{
    client->listener = listener;
}

t_bool sclienttcp_get_active(t_sclienttcp* client)
{
    return client->active_status;
}

t_sclienttcp_remote_server* sclienttcp_get_server(t_sclienttcp* client)
{
    return client->remote_srv;
}

void sclienttcp_set_server(t_sclienttcp* client, t_sclienttcp_remote_server* srv)
{
    client->remote_srv->port = srv->port;
    client->remote_srv->address = srv->address;

    client->recv_buff = realloc(client->recv_buff,srv->recv_buff_size*sizeof(unsigned char));
    client->remote_srv->recv_buff_size = srv->recv_buff_size;
}

int sclienttcp_socket_connect(t_sclienttcp* client)
{
    int status;
    struct in_addr addr;

    if(client->connect_resolution == true){
        client->address_in->sin_family = AF_INET;
        if(inet_aton(client->remote_srv->address,&addr) == 0){
            call_listener(client,ON_ERROR,(void*)ERR_IP_ADDRESS);
            return -1;
        } 
        client->address_in->sin_addr.s_addr = addr.s_addr;
        client->address_in->sin_port = htons(client->remote_srv->port);
        
        pthread_attr_init(&client->attr);
        client->terminate = false;
        status = pthread_create(&client->tid,&client->attr,execute_thread,client);
        if(status!=0){
            call_listener(client,ON_ERROR,(void*)ERR_CREATE_THREAD);
            return status;
        }       
        client->connect_resolution = false;
    }
    return 0;
}

int sclienttcp_socket_disconnect(t_sclienttcp* client)
{
    int status;

    client->terminate = true;
    client->active_status = false;
    client->connect_resolution = true;

    shutdown(client->fd_socket, 2);
    status = close(client->fd_socket);
    if(status < 0){
        call_listener(client,ON_ERROR,(void*)ERR_CLOSE_SOCKET);
        return status;
    } 
    call_listener(client,ON_DISCONNECT,NULL);

    return 0;
}

unsigned char* sclienttcp_data_pull(t_sclienttcp* client)
{
    return client->recv_buff;
}

int sclienttcp_data_push(t_sclienttcp* client, unsigned char *bytes, int len)
{
    int status;
    status = write(client->fd_socket, bytes, len);
    if(status < 0){
        call_listener(client,ON_ERROR,(void*)ERR_PUSH);
        return status;
    }
    return 0;
}
