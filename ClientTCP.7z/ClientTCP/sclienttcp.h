#ifndef _CLIENTTCP_H_
#define _CLIENTTCP_H_

#include <stdlib.h>
#include "sfuns.h"

typedef struct sclienttcp_remote_server 
{
    char* address;
    int   port;
    int   recv_buff_size;
} t_sclienttcp_remote_server;

typedef enum sclienttcp_errors_socket
{
   ERR_CREATE_SOCKET = -1,
   ERR_CREATE_THREAD = -2,
   ERR_IP_ADDRESS = -3,
   ERR_CONNECT = -5,
   ERR_CLOSE_SOCKET = -6,
   ERR_WRITE = -7,
   ERR_PUSH = -8,
   ERR_CREATE_MUTEX = -9,
   ERR_DESTROY_MUTEX = -10,
   ERR_READ_DATA = -11
} t_sclienttcp_errors_socket;

struct sclienttcp;
typedef struct sclienttcp t_sclienttcp;

typedef struct sclienttcp_events
{
    void (*on_connect)(t_sclienttcp* client);
    void (*on_disconnect)(t_sclienttcp* client);
    void (*on_data_received)(t_sclienttcp* client, void* n_bytes);
    void (*on_error)(t_sclienttcp* client, void* error);
} t_sclienttcp_events;

t_sclienttcp* sclienttcp_create(int* exception);
void sclienttcp_destroy(t_sclienttcp* client);

void sclienttcp_set_listener(t_sclienttcp* client, t_sclienttcp_events* listener);

t_bool sclienttcp_get_active(t_sclienttcp* client);
t_sclienttcp_remote_server* sclienttcp_get_server(t_sclienttcp* client);
void sclienttcp_set_server(t_sclienttcp* client, t_sclienttcp_remote_server* srv);

int sclienttcp_socket_connect(t_sclienttcp* client);
int sclienttcp_socket_disconnect(t_sclienttcp* client);
unsigned char* sclienttcp_data_pull(t_sclienttcp* client);
int sclienttcp_data_push(t_sclienttcp* client, unsigned char *bytes, int len);

#endif