#ifndef _FILEGUIDE_H_
#define _FILEGUIDE_H_

#include <time.h>
#include <sys/stat.h>

#ifndef false
#define false 0
#endif

#ifndef true
#define true  1
#endif

#ifndef t_bool
typedef unsigned char t_bool;
#endif

static char* type_file_ru[] ={
    "Не известный тип",
    "Именованый канал",
    "Символьное устройство","",
    "Каталог","",
    "Блочное устройство","",
    "Обычный файл","",
    "Символическая ссылка","",
    "Доменный сокет","",
    "Пробел"
};

static char* type_file_en[] ={
    "Unknown type",
    "Named pipe, or FIFO",
    "Character device","",
    "Directory","",
    "Block device","",
    "Regular file","",
    "Symbolic link","",
    "Local domain socket","",
    "White"
};

static char* err_txt_en[] ={
    "The function call busy.",
    "Wrong name of path.",
    "Couldn't open the directory.",
    "Couldn't create thread",
    "Unable to allocate memory"
};

static char* err_txt_ru[] ={
    "Функция занята.",
    "Не правильное имя пути.",
    "Не возможно открыть директорию.",
    "Ошибка создания потока",
    "Невозможно выделить память"
};

typedef enum errors{
    ERR_FUN_BUSY,
    ERR_WRONG_NAME,
    ERR_OPEN_DIR,
    ERR_THREAD_CREATE,
    ERR_ALLOCATE_MEMORY
} t_errors;

typedef enum sortmode{
    SORT_NAME_INC,
    SORT_NAME_DEC,
    SORT_TYPE_INC,
    SORT_TYPE_DEC,
    SORT_SIZE_INC,
    SORT_SIZE_DEC,
    SORT_DATA_INC,
    SORT_DATA_DEC,
    SORT_USER_INC,
    SORT_USER_DEC
}t_sortmode;

typedef struct filename {
    unsigned char type;
    int attr_status;
    char* name;
    struct stat attr;
}t_filename;

typedef struct filelist {
    t_filename** dir;
    int n_files;
} t_filelist;

struct fileguide;
typedef struct fileguide t_fileguide;

typedef struct fileguide_events {
   void (*on_sorted)(t_fileguide* guide, t_filelist* list);
   void (*on_readdir)(t_fileguide* guide, t_filelist* list); 
   void (*on_error)(t_fileguide* guide, void* error);
} t_fileguide_events;

t_fileguide* fileguide_create(void* parent, int* exception);
void fileguide_destroy(t_fileguide* guide);

void fileguide_set_listener(t_fileguide* guide, t_fileguide_events* listener);

void fileguide_set_parent(t_fileguide* guide, void* parent);
void* fileguide_get_parent(t_fileguide* guide);

void fileguide_sortlist(t_fileguide* guide, t_sortmode mode);
void fileguide_readdir(t_fileguide* guide, char* dirpath);

t_filename* fileguide_fselect(t_fileguide* guide, const char* name);
t_filelist* fileguide_get_list(t_fileguide* guide);

#endif