#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fileguide.h"

void on_sorted(t_fileguide* guide, t_filelist* list)
{
    int i;

    for(i=0;i<list->n_files;i++){
        printf("%s %d %s %d\n",
                list->dir[i]->name,
                list->dir[i]->attr.st_size, 
                type_file_ru[list->dir[i]->type],
                list->dir[i]->attr_status
        );
    }
}
void on_readdir(t_fileguide* guide, t_filelist* list)
{
    int i;
    for(i=0;i<list->n_files;i++){
        printf("%s %d %s %d\n",
                list->dir[i]->name,
                list->dir[i]->attr.st_size, 
                type_file_ru[list->dir[i]->type],
                list->dir[i]->attr_status
        );
    }
} 
void on_error(t_fileguide* guide, void* error)
{
    t_errors num_err = *(t_errors*)error;
    printf("Error: %s\n",err_txt_ru[num_err]);
}

void findwords(char const *source, char* dest[], int* count)
{
    int i,j,len;

    *count = 0;
    if(strlen(source) == 0) return;

    len =0; while(source[len])len++;
    j=0;
    for(i=0;i<len;i++)
    {
        if((source[i]==' ')||(i==(len-1))){
            dest = (char**)realloc(dest,(*count+1)*sizeof(char*));
            dest[*count] = (char*)malloc(i-j);
            strncpy(dest[*count],&source[j],i-j);
            j=i;
            *count++;
        }
    }
}

int main(int argc, char const *argv[])
{
    t_fileguide* guide;
    t_fileguide_events guide_listener;
    int err;
    int len;
    char* path;
    t_filename* fname;
    int i,n;

    guide_listener.on_error = on_error;
    guide_listener.on_readdir = on_readdir;
    guide_listener.on_sorted = on_sorted;
    
    guide = fileguide_create(NULL,&err);
    if(guide == NULL){
        printf("Error: %d\n",err);
        return err;
    }

    fileguide_set_listener(guide,&guide_listener);

    while(1){
        path = (char*)realloc(path,32);
        if(path!=NULL){
            memset(path,0,32);
            scanf("%s",path);
            len=strlen(path);
            path = (char*) realloc(path,len);
            if(path!=NULL){
                if(0 == strcmp("exit",path)) break;
                
                if(0 == strcmp("sortdec",path)){
                    fileguide_sortlist(guide,SORT_NAME_DEC);
                } else if(0 == strcmp("sortinc",path)){
                    fileguide_sortlist(guide,SORT_NAME_INC);
                } else if(0 == strcmp("select",path)){
                    fname = fileguide_fselect(guide,"proba");
                    if (fname == NULL){ 
                        printf("NO\n");
                    }else{ 
                        printf("Ok: %s %d\n",fname->name,fname->attr.st_size);
                    }
                }else{
                    fileguide_readdir(guide, path);
                }
            }
        }
    }
    free(path);
    fileguide_destroy(guide);

    return 0;
}