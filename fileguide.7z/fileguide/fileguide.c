#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>
#include <pthread.h>
#include <string.h>
#include <sys/stat.h>
#include "fileguide.h"

static pthread_mutex_t mutex;
static t_bool single_init = false;
static int n_guide = 0;

typedef struct targs{
    t_fileguide* guide; 
    void* arg;
} t_targs;

typedef struct read_args{
    t_fileguide* guide; 
    char* path;
} t_read_args;


struct fileguide
{
    t_filelist list;
    void* parent;
    t_fileguide_events* listener;

    pthread_t sorttid;
    pthread_t readtid;
    t_bool busy; //исключает многократный запуск функций при работе потока
};

t_fileguide* fileguide_create(void* parent, int* exception)
{
    int status;

    t_fileguide* new_fileguide = malloc(sizeof(t_fileguide));
    if(new_fileguide == NULL){
        *exception = errno;
    }

    if(single_init == false) { 
        status = pthread_mutex_init(&mutex,NULL);
        if(0!=status){
            *exception = status;
            free(new_fileguide);
            return NULL;
        }
        single_init = true; 
    }

    new_fileguide->parent = parent;
    new_fileguide->busy = false;

    return new_fileguide;
}
void fileguide_destroy(t_fileguide* guide)
{
    if(n_guide > 0){
        pthread_join(guide->sorttid,NULL);
        pthread_join(guide->readtid,NULL);
        while(guide->list.n_files > 0){
            guide->list.n_files--;
            free(guide->list.dir[guide->list.n_files]->name);
            free(guide->list.dir[guide->list.n_files]);
        }
        free(guide);
        guide = NULL;
        n_guide--;
        if(n_guide == 0){
            pthread_mutex_destroy(&mutex);
            single_init = false;
        }
    }
}
void fileguide_set_listener(t_fileguide* guide, t_fileguide_events* listener)
{
    guide->listener = listener;
}
void fileguide_set_parent(t_fileguide* guide, void* parent)
{
    guide->parent = parent;
}
void* fileguide_get_parent(t_fileguide* guide)
{
    return guide->parent;
}
t_filename* fileguide_fselect(t_fileguide* guide, const char* name)
{
    for(int i=0;i<guide->list.n_files;i++){
        if(strcmp(name,guide->list.dir[i]->name)==0){  
            return guide->list.dir[i];
        }
    }
    return NULL;
}
void change_items(t_filename** list, int i, int j)
{
    t_filename* t;

    t = list[i];
    list[i] = list[j];
    list[j] = t;
}

void sortfiles(t_filelist* filelist, t_sortmode* mode)
{
    int i,j; 
    
    #define list filelist->dir
    #define size_list filelist->n_files

    for (i = 0; i < size_list; i++) {
        for (j = i + 1; j < size_list; j++) {
            switch (*mode)
            {
            case SORT_NAME_INC:{
                if (strcmp(list[i]->name, list[j]->name) > 0)change_items(list,i,j);
            }break;
            case SORT_NAME_DEC:{
                if (strcmp(list[i]->name, list[j]->name) < 0)change_items(list,i,j);
            }break;
            case SORT_TYPE_INC:{    
                if (list[i]->type > list[j]->type)change_items(list,i,j);
            }break;
            case SORT_TYPE_DEC:{
                if (list[i]->type < list[j]->type)change_items(list,i,j); 
            }break;
            case SORT_SIZE_INC:{
                if (list[i]->attr.st_size > list[j]->attr.st_size)change_items(list,i,j);
            }break;
            case SORT_SIZE_DEC:{
                if (list[i]->attr.st_size < list[j]->attr.st_size)change_items(list,i,j); 
            }break;
            case SORT_DATA_INC:{
                if ( list[i]->attr.st_ctime > list[j]->attr.st_ctime)change_items(list,i,j);
            }break;
            case SORT_DATA_DEC:{
                if (list[i]->attr.st_ctime < list[j]->attr.st_ctime)change_items(list,i,j); 
            }break;
            case SORT_USER_INC:{
                if (list[i]->attr.st_uid > list[j]->attr.st_uid)change_items(list,i,j);
            }break;
            case SORT_USER_DEC:{
                if (list[i]->attr.st_uid < list[j]->attr.st_uid)change_items(list,i,j); 
            }break;
            }
        }
    }

    #undef list
    #undef size_list
}
void* thread_sortlist(void* arg)
{
    t_targs* sargs = (t_targs*) arg;

    pthread_mutex_lock(&mutex);
        sortfiles(&sargs->guide->list, (t_sortmode*)sargs->arg);
    pthread_mutex_unlock(&mutex);
    sargs->guide->listener->on_sorted(sargs->guide, &sargs->guide->list);

    sargs->guide->busy = false;
    free(sargs);
}
void fileguide_sortlist(t_fileguide* guide, t_sortmode mode)
{
    int status;
    t_errors err;
    t_targs* args;
    
    if(guide->busy == false){
        
        args = (t_targs*)malloc(sizeof(t_targs));
        if(args == NULL){
            err = ERR_ALLOCATE_MEMORY;
            guide->listener->on_error(guide,&err);
            return;
        }
        
        args->guide=guide;
        t_sortmode* pmode = &mode;
        args->arg = (void*) pmode;

        guide->busy = true;
        status = pthread_create(&guide->sorttid,0,thread_sortlist,args);
        if(0!= status){
            free(args);
            guide->busy = false;
            err = ERR_THREAD_CREATE;
            guide->listener->on_error(guide,&err);
        }
    } else {
        err = ERR_FUN_BUSY;
        guide->listener->on_error(guide,&err);
    } 
}

void* thread_readdir(void* arg)
{
    DIR *dp;
    struct dirent* ep;
    int i;
    t_errors err;
    
    t_read_args* rargs = (t_read_args*) arg;
    
    pthread_mutex_lock(&mutex);
        dp = opendir(rargs->path);
        if(dp == NULL){
            err = ERR_OPEN_DIR;
            rargs->guide->listener->on_error(rargs->guide,&err);
            rargs->guide->busy = false;
            pthread_mutex_unlock(&mutex);
            return NULL;
        }
        #define nfiles rargs->guide->list.n_files
        #define listdir rargs->guide->list.dir
        while(nfiles > 0){
            nfiles--;
            free(listdir[nfiles]->name);
            free(listdir[nfiles]);
        }
        while ((ep = readdir(dp)) != NULL) {
            nfiles++;
            listdir = (t_filename**)realloc(listdir, nfiles*sizeof(t_filename*));
            if(listdir == NULL){
                nfiles--;
                err = ERR_ALLOCATE_MEMORY;
                rargs->guide->listener->on_error(rargs->guide,&err);
                break;
            }
            listdir[nfiles-1] = (t_filename*) malloc(sizeof(t_filename));
            if(listdir[nfiles-1] == NULL){
                nfiles--;
                listdir = (t_filename**)realloc(listdir, nfiles*sizeof(t_filename*));
                err = ERR_ALLOCATE_MEMORY;
                rargs->guide->listener->on_error(rargs->guide,&err);
                break;
            }
            listdir[nfiles-1]->type = ep->d_type;
            listdir[nfiles-1]->name = malloc(ep->d_reclen);
            if(listdir[nfiles-1]->name == NULL){
                free(listdir[nfiles]);
                nfiles--;
                listdir = (t_filename**)realloc(listdir, nfiles*sizeof(t_filename*));
                err = ERR_ALLOCATE_MEMORY;
                rargs->guide->listener->on_error(rargs->guide,&err);
                break;
            }
            for(i=0;i<ep->d_reclen;i++){
                listdir[nfiles-1]->name[i] = ep->d_name[i];
            }
        };
        closedir(dp);
        for(i=0;i<nfiles;i++){
            char* fpath = malloc(strlen(rargs->path)+strlen(listdir[i]->name)+1);
            strcpy(fpath, rargs->path);
            strcat(fpath, listdir[i]->name);
            listdir[i]->attr_status = stat(fpath,&(listdir[i]->attr));
            free(fpath);
        }   
        #undef nfiles
        #undef listdir
    pthread_mutex_unlock(&mutex);
    rargs->guide->busy = false;
    rargs->guide->listener->on_readdir(rargs->guide,&rargs->guide->list);
    free(rargs->path);
    free(rargs);
}
void fileguide_readdir(t_fileguide* guide, char* dirpath)
{
    int status;
    int i,len;
    t_errors err;
    t_read_args* parg;

    len = strlen(dirpath);
    if(0 == len){
        err = ERR_WRONG_NAME;
        guide->listener->on_error(guide,&err);
        return;
    } 

    if(dirpath[len-1] !='/'){
        dirpath = realloc(dirpath,(len+1));
        dirpath[len]='/';
    } 

    if(guide->busy == false){
        guide->busy = true;

        parg = (t_read_args*) malloc(sizeof(t_read_args));
        parg->guide = guide;
        parg->path = malloc(len+1);
        strcpy(parg->path,dirpath);
        
        status = pthread_create(&guide->readtid,0,thread_readdir,parg);
        if(0!= status){
            free(parg->path);
            free(parg);
            guide->busy = false;
            err = ERR_THREAD_CREATE;
            guide->listener->on_error(guide,&err);
        }
    } else {
        err = ERR_FUN_BUSY; 
        guide->listener->on_error(guide,&err);
    }   
}
t_filelist* fileguide_get_list(t_fileguide* guide)
{
    return &guide->list;
}